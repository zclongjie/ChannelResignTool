//
//  AppDelegate.h
//  ZCTemp
//
//  Created by 赵隆杰 on 2024/2/2.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

